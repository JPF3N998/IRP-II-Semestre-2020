import cv2 as cv

filepath = "voyage.jpg"

def imgToBoardPatternAux(name, B, G, R, nameOutput):
    img = cv.imread(name, 1)

    for y in range(0, img.shape[0]):
        offset = y % 2
        for x in range(0, img.shape[1], 2):
            img[y][x + offset] = [B, G, R]

    cv.imwrite(nameOutput, img)

imgToBoardPatternAux(filepath,255,255,255,"BLANCO"+filepath)

imgToBoardPatternAux(filepath,0,0,0,"NEGRO"+filepath)