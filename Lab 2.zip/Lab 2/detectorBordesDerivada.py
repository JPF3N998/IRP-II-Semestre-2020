import cv2 as cv
import numpy as np
import math

def calculardx(pixelIzquierdo,pixelDerecho):
    return int(pixelDerecho) - int(pixelIzquierdo)
    
def calculardy(pixelSuperior,pixelInferior):
    return int(pixelSuperior) - int(pixelInferior)

def recorrerHorizontal(image):
    
    height, width = image.shape[0],image.shape[1]
    
    canvasH = np.zeros((1, height, width), np.uint8)[0] #matriz en negro

    for y in range(height):
        for x in range(1,width-2):
            
            dx = calculardx(image[y][x-1],image[y][x+1])
            canvasH[y][x] = abs(dx)
            
    return canvasH
    
def recorrerVertical(image):
    
    height, width = image.shape[0],image.shape[1]
    
    canvasV = np.zeros((1, height, width), np.uint8)[0] #matriz en negro
    
    for y in range(1,height-2):
        for x in range(width):
            
            dy = calculardy(image[y-1][x],image[y+1][x])
            canvasV[y][x] = abs(dy)

    return canvasV
    
def superponer(horizontal,vertical):
    
    height,width = horizontal.shape[0], horizontal.shape[1]
    
    canvasSuperpuesta = np.zeros((1, height,width), np.uint8)[0] #matriz en negro
    
    for y in range(height):
        for x in range(width):
            canvasSuperpuesta[y][x] = math.sqrt( (horizontal[y][x]**2) + (vertical[y][x]**2) )
    
    return canvasSuperpuesta

imgpath = "voyage.jpg"

img = cv.imread(imgpath, 0)

h = recorrerHorizontal(img)
v = recorrerVertical(img)
superpuesta = superponer(h,v)

cv.imwrite("H_"+imgpath,h)
cv.imwrite("V_"+imgpath, v)
cv.imwrite("H+V_"+imgpath, superpuesta)


#Ref: https://www.youtube.com/watch?v=j7r3C-otk-U&ab_channel=vkedco 